from pathlib import Path
import json,hashlib,sys,collections
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'docs'/'registries'
load=lambda s: json.loads((R/s).read_text())
req=load('REQUIREMENT_TO_ENGINE_MATRIX_v3.1.json')
ph=load('PHASE_EXECUTION_DAG_v3.1.json')['canonical_build_sequence']
tasks=load('TASK_DEPENDENCY_GRAPH_v3.1.json')['tasks']
tests=load('RELEASE_AND_TEST_GATES_v3.1.json')['new_test_cases']
assert req['historic_original_count']==80, req['historic_original_count']
assert len(req['requirements'])==req['historic_original_count']+req['new_delta_count']
ids=[a['req_id'] for a in req['requirements']]
assert len(set(ids))==len(ids),[k for k,v in collections.Counter(ids).items() if v>1]
pids={x['phase_id'] for x in ph};assert len(pids)==len(ph)
for p in ph: assert set(p['dependencies'])<=pids
workids={t['id'] for t in tasks};assert len(workids)==len(tasks)
for t in tasks: assert set(t['depends_on'])<=workids
seen=set()
def visit(x,stack):
  if x in stack: raise AssertionError('CYCLE '+x)
  if x in seen:return
  task=next(t for t in tasks if t['id']==x)
  for d in task['depends_on']:visit(d,stack|{x})
  seen.add(x)
for t in tasks:visit(t['id'],set())
assert all(t['status']=='NOT_RUN' for t in tests)
source=ROOT/'docs'/'canon'/'XRAI_ULU_EVREN_COMPLETE_BUILD_CONSTITUTION_v3.1.md'
assert source.exists() and '## §69' in source.read_text()
print(f'PASS: {len(ids)} unique reqs, {len(ph)} phases, {len(tasks)} acyclic work items, {len(tests)} NOT_RUN test plans, v3.1 master exists.')
