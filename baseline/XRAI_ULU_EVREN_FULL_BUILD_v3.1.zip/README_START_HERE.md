# XRAI — ULU EVREN REAL BUILD SYSTEM v3.1 — Start Here

This package upgrades the previous v3.0 without deleting historical material. It is an **implementation-ready specification package**, not a finished iOS app.

## Active app
Only XRAI. AHTOVIA is future separate sister app; the typed learning bridge is reserved and must not be developed in this work session.

## File layout
- `docs/canon/XRAI_ULU_EVREN_COMPLETE_BUILD_CONSTITUTION_v3.1.md` — newest §§54–69 + full verbatim v3.0, itself preserving entire v2.1.
- `baseline/XRAI_ULU_EVREN_CLAUDE_MASTER_BUILD_PACKAGE_v3.0.zip` — previous entire archive of historical notes and machine registries.
- `docs/registries/*.json` — machine-readable implementation plans, ADRs, policies, graph, risks, tests, source licenses.
- `.claude/skills/*/SKILL.md` and `.claude/agents/*.md` — project-specialist workflows; review before copying, never install untrusted remote code.
- `CLAUDE_PASTE_FIRST_v3.1.md` — the first user-facing Claude task (P00/conditional P01).
- `validation/validate_package.py` — package metadata and first-task/phase DAG integrity validator.
- `INTEGRITY_SHA256.json` — signed only by hash, not a cryptographic signature.

## Install on user's Mac — safe manual workflow
1. Extract ZIP in a **separate** folder. Do not overwrite any existing file under `~/Projects/XRAI` without review.
2. Back up/commit your existing repo in an approved way, inspect `git status`.
3. Merge/copy the package's `docs/canon`, `docs/registries` and optional `.claude` into XRAI repository **only after comparing paths and checking conflicts**. Do not put the huge book scan PDFs into git.
4. Copy `CLAUDE_PASTE_FIRST_v3.1.md` or paste the first prompt manually. Claude should run P00, then P01 if feasible; no risky installs/paid providers/deployments.
5. Return Claude's BOOT_00_REPORT, actual test logs and diff to ChatGPT for next-turn independent engineering audit.

## Status
All advanced math, psychometrics, HD charts, actual vault and local model runtime are planned unless present and verified in the user's actual repo. Legal rights and app review are NOT approved. The current master is not a mathematical oracle or scientific evidence for destiny.
