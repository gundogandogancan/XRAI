# XRAI build constitution (compact always-on)

**Active project XRAI ONLY.** Canonical source: `docs/canon/XRAI_ULU_EVREN_COMPLETE_BUILD_CONSTITUTION_v3.1.md` §§54–69 first; retained v3.0 §§39–53 and v2.1 as relevant. Read selective sections, not all 1.7MB in each agent context.

MUST: repo audit P00 first; baseline actual Git state; no deletions/overwrites; clean-room copyrighted book sources; local sensitive graph; consent/egress deny; pure deterministic math; scientific vs symbolic distinct; human agency; `SPECIFIED != DONE`; verified tests only.

FIRST CODE only P01: typed Swift LifePath pure calculator and independent goldens, no real user profile persisted until vault P02 tested.

No untrusted skills/plugins/MCP installs, no external paid calls, no deployment/git push. Reserve AHTOVIA integration interface only.

Use `.claude/skills/` on demand and `.claude/agents/` scoped for QA; never make agents unboundedly read full private life data.

Every response to user: changed files, exact tests/exit code, pending blockers and one next action, then STOP for user+ChatGPT review.
